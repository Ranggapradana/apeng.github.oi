<?php

$renzxhosting = 'renzhosting@gmail.com'; // EMAIL KAMU

$renzhosting = 'Jangan Hapus Copyright'; // NO REEDIT

?>